﻿// Backend-compatible version of dashboard links
const dashboardLinks = [
  // SEO Performance
  {
    id: 1,
    title: "IM Holding Arabia Audit",
    description:
      "Comprehensive SEO metrics, rankings, and performance analytics",
    url: "https://lookerstudio.google.com/reporting/cd2cda87-5149-459d-a423-2f5808c55ffe",
    category: "SEO",
    icon: "🔍",
    backgroundColor: "#4CAF50",
    tags: ["analytics", "performance", "rankings", "seo", "im holding"],
  },
  {
    id: 11,
    title: "Core Construction Audit ",
    description:
      "Comprehensive SEO metrics, rankings, and performance analytics",
    url: "https://lookerstudio.google.com/reporting/f4988046-c9c4-4148-9ed1-5310c744fee9",
    category: "SEO",
    icon: "🔍",
    backgroundColor: "#4CAF50",
    tags: ["analytics", "performance", "rankings", "seo", "im holding"],
  },
  {
    id: 12,
    title: "HNI UAE Audit ",
    description:
      "Comprehensive SEO metrics, rankings, and performance analytics",
    url: "https://lookerstudio.google.com/reporting/f4988046-c9c4-4148-9ed1-5310c744fee9",
    category: "SEO",
    icon: "🔍",
    backgroundColor: "#4CAF50",
    tags: ["analytics", "performance", "rankings", "seo", "hni"],
  },
  {
    id: 13,
    title: "HNI SA Audit ",
    description:
      "Comprehensive SEO metrics, rankings, and performance analytics",
    url: "https://lookerstudio.google.com/reporting/cbccfd86-f356-4f1f-a816-b33758f95bee",
    category: "SEO",
    icon: "🔍",
    backgroundColor: "#4CAF50",
    tags: ["analytics", "performance", "rankings", "seo", "hni"],
  },
  {
    id: 14,
    title: "Kent College Audit ",
    description:
      "Comprehensive SEO metrics, rankings, and performance analytics",
    url: "https://lookerstudio.google.com/reporting/751ade1c-e484-48ba-ba5f-239992e519df",
    category: "SEO",
    icon: "🔍",
    backgroundColor: "#4CAF50",
    tags: ["analytics", "performance", "rankings", "seo", "kent"],
  },
  {
    id: 15,
    title: "IM Solutions Audit ",
    description:
      "Comprehensive SEO metrics, rankings, and performance analytics",
    url: "https://lookerstudio.google.com/reporting/b78cc8da-9878-4660-8abc-fbe5ec2a31a4",
    category: "SEO",
    icon: "🔍",
    backgroundColor: "#4CAF50",
    tags: ["analytics", "performance", "rankings", "seo", "im", "solutions"],
  },
  {
    id: 16,
    title: "Hardware Egypt Audit ",
    description:
      "Comprehensive SEO metrics, rankings, and performance analytics",
    url: "https://lookerstudio.google.com/reporting/c2bf8e06-2942-4658-a3f2-6d1fdb58b510",
    category: "SEO",
    icon: "🔍",
    backgroundColor: "#4CAF50",
    tags: ["analytics", "performance", "rankings", "seo", "hardware"],
  },
  {
    id: 17,
    title: "SEO Project KPIs",
    description:
      "Comprehensive SEO metrics Tracking, KPI evaluation, and performance analytics",
    url: "https://datastudio.google.com/reporting/f1a82a8b-b3d9-4b0f-9222-90b1e957e157",
    category: "SEO",
    icon: "🔍",
    backgroundColor: "#4CAF50",
    tags: [
      "IM Holding Arabia",
      "KPIs",
      "rankings",
      "seo",
      "The Propster",
      "Core Construction",
    ],
  },
  {
    id: 18,
    title: "The Box Audit",
    description:
      "Comprehensive SEO metrics Tracking, KPI evaluation, and performance analytics",
    url: "https://datastudio.google.com/reporting/3b691195-5d28-4b1c-ba5f-e930e3e45a99",
    category: "SEO",
    icon: "🔍",
    backgroundColor: "#4CAF50",
    tags: ["The Box", "rankings", "seo"],
  },
  {
    id: 2,
    title: "Zanussi Requests ",
    description: "Detailed metrics and analytics of requests for Zanussi site",
    url: "https://lookerstudio.google.com/s/o1XBdxBhICE",
    category: "Client Requests",
    icon: "📊",
    backgroundColor: "#2196F3",
    tags: ["zanussi", "analytics", "performance"],
  },
  {
    id: 3,
    title: "Propster Requests ",
    description: "Detailed metrics and analytics of requests for Propster site",
    url: "https://lookerstudio.google.com/s/lWalxcXLfd8",
    category: "Client Requests",
    icon: "📈",
    backgroundColor: "#2196F3",
    tags: ["propster", "analytics", "performance"],
  },
  {
    id: 6,
    title: "Zanussi Requests Form",
    description: "Submit Zanussi project requests and issues",
    url: "https://script.google.com/macros/s/AKfycbymkqgeNlLsLTEyfaEUmLUXfILKm57IFoUD2YNihm5mr1yrTJvsn3n59DDLvvdQvzfZjg/exec",
    category: "Forms",
    icon: "📝",
    backgroundColor: "#ff6600",
    tags: ["zanussi", "requests", "form", "submission"],
  },
  {
    id: 7,
    title: "Project Requests Form",
    description: "Submit new project requests or modifications",
    url: "https://script.google.com/macros/s/AKfycbw70pFy667_2SxINH5740lscv8h9RS9eGzC6utZJw5AoOcn1mMGC4wX95LOGl5CrCljtA/exec",
    category: "Forms",
    icon: "🚀",
    backgroundColor: "#ff6600",
    tags: ["projects", "requests", "submission"],
  },
  {
    id: 8,
    title: "Weekly KPI Submission",
    description: "Employee weekly performance KPI tracking and submission",
    url: "https://script.google.com/macros/s/AKfycbwRNBSDi0LWmMCfEUY3N-ni8rrL1HiUArT0YHKRjco_HeSq-wKHmht-K8-BDrjl1hvjMw/exec",
    category: "Forms",
    icon: "⭐",
    backgroundColor: "#ff6600",
    tags: ["kpi", "performance", "employees", "weekly"],
  },
  {
    id: 9,
    title: "Employee Performance Dashboard",
    description:
      "Weekly KPI tracking and performance analytics for all employees",
    url: "https://lookerstudio.google.com/s/gDZZqoCmGGU",
    category: "Employee KPI",
    icon: "👨‍💼",
    backgroundColor: "#FF9800",
    tags: ["employees", "performance", "kpi", "analytics"],
  },
];

// Helper functions (needed for backend)
const getLinksByCategory = (category) => {
  return dashboardLinks.filter((link) => link.category === category);
};

const getAllCategories = () => {
  const categories = dashboardLinks.map((link) => link.category);
  return [...new Set(categories)];
};

const getCategoryCounts = () => {
  const counts = {};
  dashboardLinks.forEach((link) => {
    counts[link.category] = (counts[link.category] || 0) + 1;
  });
  return counts;
};

// Export for Node.js (CommonJS format)
module.exports = {
  dashboardLinks,
  getLinksByCategory,
  getAllCategories,
  getCategoryCounts,
};
